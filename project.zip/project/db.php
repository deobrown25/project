<?php
// Detect environment: local (XAMPP) or live (InfinityFree)
if ($_SERVER['SERVER_NAME'] == "localhost" || $_SERVER['SERVER_NAME'] == "127.0.0.1") {
    // Local XAMPP settings
    $servername = "localhost";
    $username = "root";         // default XAMPP username
    $password = "";             // default XAMPP password (empty)
    $dbname = "school_db";      // local database name
} else {
    // InfinityFree live settings
    $servername = "sql302.infinityfree.com";  // MySQL host from InfinityFree
    $username = "if0_41481531";               // InfinityFree DB username
    $password = "123schoolproject";              // InfinityFree DB password
    $dbname = "if0_41481531_school_db";      // InfinityFree DB name
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>