<?php
include 'db.php'; // Connects to your database
?>

<!DOCTYPE html>
<html>
<head>
    <title>Enrolled Students</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Enrolled Students</h2>
<p>Retrieved at: <?php echo date("Y-m-d H:i:s"); ?></p>

<table>
    <tr>
        <th>Student ID</th>
        <th>Student Name</th>
        <th>CRN</th>
        <th>Course Days</th>
        <th>Course Time</th>
        <th>Classroom</th>
    </tr>

<?php
$sql = "SELECT enrolled.student, student.first_name, student.last_name,
               course.crn, course.days, course.time,
               classroom.building, classroom.room
        FROM enrolled
        JOIN student ON enrolled.student = student.student_id
        JOIN course ON enrolled.course = course.crn
        JOIN classroom ON course.classroom = classroom.id
        ORDER BY student.last_name";

$result = $conn->query($sql);

if (!$result) {
    die("Error retrieving enrolled data: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['student']}</td>
        <td>{$row['first_name']} {$row['last_name']}</td>
        <td>{$row['crn']}</td>
        <td>{$row['days']}</td>
        <td>{$row['time']}</td>
        <td>{$row['building']} {$row['room']}</td>
    </tr>";
}
?>

</table>

</body>
</html>